
package ch.bfh.ejb;

import javax.annotation.Resource;
import javax.annotation.security.DeclareRoles;
import javax.annotation.security.RolesAllowed;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;

/**
 *
 * AP
 */
@Stateless
//Benutzer deklarieren, da die Funktion isCallerInRole verwendet wird
@DeclareRoles({"user", "administrator"})
public class SecureServiceEJB implements SecureServiceEJBLocal {

    @Resource
    private SessionContext sctx;
    
    @Override
    public String echo(String input) {
      return input;
    }

    @Override
    @RolesAllowed({"user", "administrator"}) //erlaubt sind user und admin
    public String readInternalData() {
        String role = ""; 
        if (sctx.isCallerInRole("user")) {
          role = "user";  
        } else {
          role = "administrator";   
        }
        String name = sctx.getCallerPrincipal().getName();
        
        class Local {}
        String method = Local.class.getEnclosingMethod().getName();
        log(name, method);
        return "readInternalData for role " + name ;
    }

    @Override
    @RolesAllowed({"administrator"}) //erlaubt ist admin
    public String readConfidentalData() {
        String name = sctx.getCallerPrincipal().getName();
        
        class Local {}
        String method = Local.class.getEnclosingMethod().getName();
        log(name, method);
        
        return "readConfidentalData for " + name ;
    }

    /**
     * log user
     * @param logString 
     */
    private void log(String user, String method) {
        System.out.println(this.getClass().getName() + ":" +method + " ->"+ user);
    }
    
}
