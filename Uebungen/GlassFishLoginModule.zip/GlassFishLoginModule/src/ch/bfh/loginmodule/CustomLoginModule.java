package ch.bfh.loginmodule;

import com.sun.appserv.security.AppservPasswordLoginModule;
import java.util.HashMap;
import javax.security.auth.Subject;
import javax.security.auth.login.LoginException;

/**
 *
 * @author
 */
public class CustomLoginModule extends AppservPasswordLoginModule {

    private static HashMap<String, String> userlist = new HashMap<String, String>();
    private RadiusAuthentication auth = new RadiusMock();
    
    public CustomLoginModule() {
        System.out.println("CustomLoginModule LoginModule - Construction");
        //mock -> stativ user / group
        userlist.put("user1", "user");
        userlist.put("user2", "user");
        userlist.put("user3", "user");
        userlist.put("admin", "administrator");
    }

    @Override
    protected void authenticateUser() throws LoginException {
        
        //write here the login code
        //get pw and user from superclass ->  _username / _passwd

        //when everything is ok -> commit group, else throw LoginException
        //commitUserAuthentication(groups);    

    }

}
